using UnityEngine;

public class Settings : MonoBehaviour
{
    public int gameDifficulty = 1;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
